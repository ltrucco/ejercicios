require './construction_block_type'

class LeftTransporterType < ConstructionBlockType
end
