require 'minitest/autorun'
require 'minitest/reporters'
require './point'
require './pacman'
require './ghost'
require './wall_type'
require './space_type'
require './left_transporter_type'
require './ghost_house_door_type'

MiniTest::Reporters.use!

class PacmanTest < MiniTest::Unit::TestCase

  def setup
    @pacman = Pacman.new
    @blueGhost = Ghost.new
    @wallType = WallType.new
    @spaceType = SpaceType.new
    @leftTransporterType = LeftTransporterType.new
    @ghostHouseDoorType = GhostHouseDoorType.new

    @left = Point.new -1,0
    @right = Point.new 1,0
    @up = Point.new 0,1
    @down = Point.new 0,-1
  end

  def test_01_ghost_can_not_go_into_a_wall
    assert_equal(
        @blueGhost.position,
        @wallType.next_position_for_going(@blueGhost, @left))

    assert_equal(
        @blueGhost.position,
        @wallType.next_position_for_going(@blueGhost, @right))

    assert_equal(
        @blueGhost.position,
        @wallType.next_position_for_going(@blueGhost, @up))

    assert_equal(
        @blueGhost.position,
        @wallType.next_position_for_going(@blueGhost, @down))
  end

  def test_02_pacman_can_not_go_into_a_wall
    assert_equal(
        @pacman.position,
        @wallType.next_position_for_going(@pacman, @left))

    assert_equal(
        @pacman.position,
        @wallType.next_position_for_going(@pacman, @right))

    assert_equal(
        @pacman.position,
        @wallType.next_position_for_going(@pacman, @up))

    assert_equal(
        @pacman.position,
        @wallType.next_position_for_going(@pacman, @down))
  end

  def test_03_pacman_moves_fast_into_spaces
    assert_equal(
        @pacman.position + Point.new(-2,0),
        @spaceType.next_position_for_going(@pacman, @left))

    assert_equal(
        @pacman.position + Point.new(2,0),
        @spaceType.next_position_for_going(@pacman, @right))

    assert_equal(
        @pacman.position + Point.new(0,2),
        @spaceType.next_position_for_going(@pacman, @up))

    assert_equal(
        @pacman.position + Point.new(0,-2),
        @spaceType.next_position_for_going(@pacman, @down))

  end

  def test_04_ghost_moves_slowly_into_spaces
    assert_equal(
        @blueGhost.position + Point.new(-1,0),
        @spaceType.next_position_for_going(@blueGhost, @left))

    assert_equal(
        @blueGhost.position + Point.new(1,0),
        @spaceType.next_position_for_going(@blueGhost, @right))

    assert_equal(
        @blueGhost.position + Point.new(0,1),
        @spaceType.next_position_for_going(@blueGhost, @up))

    assert_equal(
        @blueGhost.position + Point.new(0,-1),
        @spaceType.next_position_for_going(@blueGhost, @down))
  end

  def test_05_ghost_can_enter_his_house
    assert_equal(
        @blueGhost.position + Point.new(-1,0),
        @ghostHouseDoorType.next_position_for_going(@blueGhost, @left))

    assert_equal(
        @blueGhost.position + Point.new(1,0),
        @ghostHouseDoorType.next_position_for_going(@blueGhost, @right))

    assert_equal(
        @blueGhost.position + Point.new(0,1),
        @ghostHouseDoorType.next_position_for_going(@blueGhost, @up))

    assert_equal(
        @blueGhost.position + Point.new(0,-1),
        @ghostHouseDoorType.next_position_for_going(@blueGhost, @down))
  end

  def test_06_pacman_can_not_enter_ghost_house
    assert_equal(
        @pacman.position,
        @ghostHouseDoorType.next_position_for_going(@pacman, @left))

    assert_equal(
        @pacman.position,
        @ghostHouseDoorType.next_position_for_going(@pacman, @right))

    assert_equal(
        @pacman.position,
        @ghostHouseDoorType.next_position_for_going(@pacman, @up))

    assert_equal(
        @pacman.position,
        @ghostHouseDoorType.next_position_for_going(@pacman, @down))
  end

  def test_07_transporter_moves_pacman_to_new_position
    assert_equal(
        Point.new(10,4),
        @leftTransporterType.next_position_for_going(@pacman, @left))

    assert_equal(
        Point.new(10,4),
        @leftTransporterType.next_position_for_going(@pacman, @right))
  end

  def test_08_ghost_can_not_go_into_transporter
    assert_equal(
        @blueGhost.position,
        @leftTransporterType.next_position_for_going(@blueGhost, @left))

    assert_equal(
        @blueGhost.position,
        @leftTransporterType.next_position_for_going(@blueGhost, @right))
  end
end
