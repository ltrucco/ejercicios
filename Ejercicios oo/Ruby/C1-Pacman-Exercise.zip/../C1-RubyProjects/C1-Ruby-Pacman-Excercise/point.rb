class Point

  def initialize(x,y)
    @x = x
    @y = y
  end

  def x
    return @x
  end

  def y
    return @y
  end

  def +(a_point)
    Point.new @x+a_point.x, @y+a_point.y
  end

  def ==(an_object)
    an_object.kind_of? self.class && (@x==an_object.x && @y==an_object.y)
  end
end
