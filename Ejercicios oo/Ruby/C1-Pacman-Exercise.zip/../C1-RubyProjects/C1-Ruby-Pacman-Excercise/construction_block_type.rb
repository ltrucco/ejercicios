class ConstructionBlockType

  def next_position_for_going(an_actor, a_direction)
    raise Exception.new 'should implement'
  end
end
