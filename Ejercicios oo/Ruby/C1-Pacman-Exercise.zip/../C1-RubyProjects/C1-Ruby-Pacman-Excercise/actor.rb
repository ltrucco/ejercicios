
class Actor
  def position
    raise Exception.new 'Subclass should implement'
  end
end