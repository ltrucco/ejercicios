require './construction_block_type'

class GhostHouseDoorType < ConstructionBlockType
end
