require './construction_block_type'

class SpaceType < ConstructionBlockType
end
