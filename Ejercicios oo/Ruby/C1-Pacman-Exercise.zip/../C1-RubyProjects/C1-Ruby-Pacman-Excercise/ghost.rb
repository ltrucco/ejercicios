require './actor'

class Ghost < Actor
end
