require './actor'

class Pacman < Actor
end
