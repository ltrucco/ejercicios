require './construction_block_type'

class WallType < ConstructionBlockType
end

