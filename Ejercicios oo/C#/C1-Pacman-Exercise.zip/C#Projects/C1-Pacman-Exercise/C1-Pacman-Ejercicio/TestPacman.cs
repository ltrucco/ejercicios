﻿/*
 * Developed by 10Pines SRL
 * License: 
 * This work is licensed under the 
 * Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. 
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/ 
 * or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View, 
 * California, 94041, USA.
 *  
 */
using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace C1_Pacman_Ejercicio
{
    [TestClass]
    public class TestPacman
    {
        protected Actor pacman;
        protected Actor blueGhost;
        protected ConstructionBlockType wallType;
        protected ConstructionBlockType spaceType;
        protected ConstructionBlockType leftTransporterType;
        protected ConstructionBlockType ghostHouseDoorType;

        protected Point left;
        protected Point right;
        protected Point up;
        protected Point down;

        [TestInitialize]
        public void setUp()
        {
        }

        [TestMethod]
        public void testGhostCanNotGoIntoAWall()
        {             
            Assert.AreEqual(
                    blueGhost.position(),
                    wallType.nextPositionForGoing(blueGhost, left));

            Assert.AreEqual(
                    blueGhost.position(),
                    wallType.nextPositionForGoing(blueGhost, right));

            Assert.AreEqual(
                    blueGhost.position(),
                    wallType.nextPositionForGoing(blueGhost, up));

            Assert.AreEqual(
                    blueGhost.position(),
                    wallType.nextPositionForGoing(blueGhost, down));
        }

        [TestMethod]
        public void testPacmanCanNotGoIntoAWall()
        {
            Assert.AreEqual(
                    pacman.position(),
                    wallType.nextPositionForGoing(pacman, left));

            Assert.AreEqual(
                    pacman.position(),
                    wallType.nextPositionForGoing(pacman, right));

            Assert.AreEqual(
                    pacman.position(),
                    wallType.nextPositionForGoing(pacman, up));

            Assert.AreEqual(
                    pacman.position(),
                    wallType.nextPositionForGoing(pacman, down));
        }

        [TestMethod]
        public void testPacmanMovesIntoSpacesVeryFast()
        {
            Assert.AreEqual(
                    pacman.position().plus(new Point(-2, 0)),
                    spaceType.nextPositionForGoing(pacman, left));

            Assert.AreEqual(
                    pacman.position().plus(new Point(2, 0)),
                    spaceType.nextPositionForGoing(pacman, right));

            Assert.AreEqual(
                    pacman.position().plus(new Point(0, 2)),
                    spaceType.nextPositionForGoing(pacman, up));

            Assert.AreEqual(
                    pacman.position().plus(new Point(0, -2)),
                    spaceType.nextPositionForGoing(pacman, down));

        }

        [TestMethod]
        public void testGhostMovesIntoSpacesSlowly()
        {
            Assert.AreEqual(
                    blueGhost.position().plus(new Point(-1, 0)),
                    spaceType.nextPositionForGoing(blueGhost, left));

            Assert.AreEqual(
                    blueGhost.position().plus(new Point(1, 0)),
                    spaceType.nextPositionForGoing(blueGhost, right));

            Assert.AreEqual(
                    blueGhost.position().plus(new Point(0, 1)),
                    spaceType.nextPositionForGoing(blueGhost, up));

            Assert.AreEqual(
                    blueGhost.position().plus(new Point(0, -1)),
                    spaceType.nextPositionForGoing(blueGhost, down));
        }

        [TestMethod]
        public void testGhostCanEnterHisHouse()
        {
            Assert.AreEqual(
                    blueGhost.position().plus(new Point(-1, 0)),
                    ghostHouseDoorType.nextPositionForGoing(blueGhost, left));

            Assert.AreEqual(
                    blueGhost.position().plus(new Point(1, 0)),
                    ghostHouseDoorType.nextPositionForGoing(blueGhost, right));

            Assert.AreEqual(
                    blueGhost.position().plus(new Point(0, 1)),
                    ghostHouseDoorType.nextPositionForGoing(blueGhost, up));

            Assert.AreEqual(
                    blueGhost.position().plus(new Point(0, -1)),
                    ghostHouseDoorType.nextPositionForGoing(blueGhost, down));
        }

        [TestMethod]
        public void testPacmanCanNotEnterGhostHouse()
        {
            Assert.AreEqual(
                    pacman.position(),
                    ghostHouseDoorType.nextPositionForGoing(pacman, left));

            Assert.AreEqual(
                    pacman.position(),
                    ghostHouseDoorType.nextPositionForGoing(pacman, right));

            Assert.AreEqual(
                    pacman.position(),
                    ghostHouseDoorType.nextPositionForGoing(pacman, up));

            Assert.AreEqual(
                    pacman.position(),
                    ghostHouseDoorType.nextPositionForGoing(pacman, down));
        }

                [TestMethod]
        public void testTransporterMovesPacmanToNewPosition()
        {
            Assert.AreEqual(
                    new Point(10, 4),
                    leftTransporterType.nextPositionForGoing(pacman, left));

            Assert.AreEqual(
                    new Point(10, 4),
                    leftTransporterType.nextPositionForGoing(pacman, right));
        }

        [TestMethod]
        public void testGhostCanNotGoIntoTransporter()
        {
            Assert.AreEqual(
                    blueGhost.position(),
                    leftTransporterType.nextPositionForGoing(blueGhost, left));

            Assert.AreEqual(
                    blueGhost.position(),
                    leftTransporterType.nextPositionForGoing(blueGhost, right));
        }

    
    }
}
