/*
 * Developed by 10Pines SRL
 * License:
 * This work is licensed under the
 * Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/
 * or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View,
 * California, 94041, USA.
 *
 */

"use strict";
Object.prototype.shouldImplement = function () {
    throw new Error ("Should implement!");
};

function Point(x,y) {
    this.x = x;
    this.y = y;
};
Point.prototype.plus = function(aPoint){
    return new Point(this.x+aPoint.x,this.y+aPoint.y);
};

function Actor (position) {
    this.position = position;
};
Actor.prototype.nextPositionWhenGoingInto = function (block,aMovement) {
    shouldImplement();
};

function Ghost (position) {
    Actor.call(this,position);
};
Ghost.prototype = Object.create(Actor.prototype);

function Pacman (position) {
    Actor.call(this,position);
};
Pacman.prototype = Object.create(Actor.prototype);

function ConstructionBlockType () {};
ConstructionBlockType.prototype.nextPositionForGoing = function (anActor,aMovement) {
    shouldImplement();
};

function GhostHouseDoorType () {
    ConstructionBlockType.call(this);
};
GhostHouseDoorType.prototype = Object.create(ConstructionBlockType.prototype);

function LeftTransporterType () {
    ConstructionBlockType.call(this);
};
LeftTransporterType.prototype = Object.create(ConstructionBlockType.prototype);

function SpaceType () {
    ConstructionBlockType.call(this);
};
SpaceType.prototype = Object.create(ConstructionBlockType.prototype);

function WallType () {
    ConstructionBlockType.call(this);
};
WallType.prototype = Object.create(ConstructionBlockType.prototype);

var assert = require('assert');
assert.isTrue = function (aBoolean) {
    return assert.ok(aBoolean);
};

assert.isFalse = function (aBoolean) {
    return assert.isTrue (!aBoolean);
};

suite('PacmanTest',function() {

    var pacman;
    var blueGhost;
    var wallType;
    var spaceType;
    var leftTransporterType;
    var ghostHouseDoorType;

    var left;
    var right;
    var up;
    var down;

    setup(function () {
        pacman = new Pacman (new Point(1,1));
        blueGhost = new Ghost (new Point(5,5));

        wallType = new WallType ();
        spaceType = new SpaceType ();
        ghostHouseDoorType = new GhostHouseDoorType();
        leftTransporterType = new LeftTransporterType();

        left = new Point(-1,0);
        right = new Point (1,0);
        up = new Point(0,1);
        down = new Point(0,-1);
    });

    test('GhostCanNotGoIntoAWall', function (){
        assert.deepEqual(
            blueGhost.position,
            wallType.nextPositionForGoing(blueGhost,left));
        assert.deepEqual(
            blueGhost.position,
            wallType.nextPositionForGoing(blueGhost,right));

        assert.deepEqual(
            blueGhost.position,
            wallType.nextPositionForGoing(blueGhost,up));

        assert.deepEqual(
            blueGhost.position,
            wallType.nextPositionForGoing(blueGhost,down));
    });

    test('PacmanCanNotGoIntoAWall', function() {
        assert.deepEqual(
            pacman.position,
            wallType.nextPositionForGoing(pacman,left));

        assert.deepEqual(
            pacman.position,
            wallType.nextPositionForGoing(pacman,right));

        assert.deepEqual(
            pacman.position,
            wallType.nextPositionForGoing(pacman,up));

        assert.deepEqual(
            pacman.position,
            wallType.nextPositionForGoing(pacman,down));
    });

    test('PacmanMovesIntoSpacesVeryFast', function () {
        assert.deepEqual(
            pacman.position.plus(new Point(-2,0)),
            spaceType.nextPositionForGoing(pacman,left));

        assert.deepEqual(
            pacman.position.plus(new Point(2,0)),
            spaceType.nextPositionForGoing(pacman,right));

        assert.deepEqual(
            pacman.position.plus(new Point(0,2)),
            spaceType.nextPositionForGoing(pacman,up));

        assert.deepEqual(
            pacman.position.plus(new Point(0,-2)),
            spaceType.nextPositionForGoing(pacman,down));

    });

    test('GhostMovesIntoSpacesSlowly', function(){
        assert.deepEqual(
            blueGhost.position.plus(new Point(-1,0)),
            spaceType.nextPositionForGoing(blueGhost,left));

        assert.deepEqual(
            blueGhost.position.plus(new Point(1,0)),
            spaceType.nextPositionForGoing(blueGhost,right));

        assert.deepEqual(
            blueGhost.position.plus(new Point(0,1)),
            spaceType.nextPositionForGoing(blueGhost,up));

        assert.deepEqual(
            blueGhost.position.plus(new Point(0,-1)),
            spaceType.nextPositionForGoing(blueGhost,down));
    });

    test('GhostCanEnterHisHouse', function (){
        assert.deepEqual(
            blueGhost.position.plus(new Point(-1,0)),
            ghostHouseDoorType.nextPositionForGoing(blueGhost,left));

        assert.deepEqual(
            blueGhost.position.plus(new Point(1,0)),
            ghostHouseDoorType.nextPositionForGoing(blueGhost,right));

        assert.deepEqual(
            blueGhost.position.plus(new Point(0,1)),
            ghostHouseDoorType.nextPositionForGoing(blueGhost,up));

        assert.deepEqual(
            blueGhost.position.plus(new Point(0,-1)),
            ghostHouseDoorType.nextPositionForGoing(blueGhost,down));
    });

    test('PacmanCanNotEnterGhostHouse', function(){
        assert.deepEqual(
            pacman.position,
            ghostHouseDoorType.nextPositionForGoing(pacman,left));

        assert.deepEqual(
            pacman.position,
            ghostHouseDoorType.nextPositionForGoing(pacman,right));

        assert.deepEqual(
            pacman.position,
            ghostHouseDoorType.nextPositionForGoing(pacman,up));

        assert.deepEqual(
            pacman.position,
            ghostHouseDoorType.nextPositionForGoing(pacman,down));
    });

    test('TransporterMovesPacmanToNewPosition', function(){
        assert.deepEqual(
            new Point(10,4),
            leftTransporterType.nextPositionForGoing(pacman,left));

        assert.deepEqual(
            new Point(10,4),
            leftTransporterType.nextPositionForGoing(pacman,right));
    });

    test('GhostCanNotGoIntoTransporter', function(){
        assert.deepEqual(
            blueGhost.position,
            leftTransporterType.nextPositionForGoing(blueGhost,left));

        assert.deepEqual(
            blueGhost.position,
            leftTransporterType.nextPositionForGoing(blueGhost,right));
    });

});
