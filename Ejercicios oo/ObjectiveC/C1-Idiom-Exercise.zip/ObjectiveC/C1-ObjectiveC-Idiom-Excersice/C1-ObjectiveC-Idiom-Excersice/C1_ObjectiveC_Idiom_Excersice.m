//
//  C1_ObjectiveC_Idiom_Excersice.m
//  C1-ObjectiveC-Idiom-Excersice
//
//  Created by Hernan Wilkinson on 12/29/15.
//  Copyright © 2015 Hernan Wilkinson. All rights reserved.
//

#import "C1_ObjectiveC_Idiom_Excersice.h"

@implementation C1_ObjectiveC_Idiom_Excersice

@end
