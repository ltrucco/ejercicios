//
//  CustomerBookTests.m
//  CustomerBookTests
//
//  Created by hernan on 8/12/15.
//  Copyright © 2015 10Pines. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <XCTest/XCTest.h>

@interface CustomerBook : NSObject {
    
    NSMutableArray *names;
}

@end

@implementation CustomerBook

-(id)init{
    names = [NSMutableArray array];
    return self;
}

- (void) addCustomerNamed: (NSString*) name{
    if([name length]==0) { [[NSException exceptionWithName:@"Customer name can not be empty" reason:nil userInfo:nil] raise ]; }
    if([self containsCustomerNamed:name]) { [[NSException exceptionWithName:@"Customer already exists" reason:nil userInfo:nil] raise ]; }
    
    [names addObject: name];
    
}

-(BOOL) isEmpty {
    return [names count]==0;
}

- (NSUInteger)numberOfCustomers {
    return [names count];
}

- (BOOL) containsCustomerNamed: (NSString*) name {
    return [names containsObject:name];
}

- (void) removeCustomerNamed: (NSString*) name {
    if (![self containsCustomerNamed:name]) { [[NSException exceptionWithName:@"Invalid Customer name" reason:nil userInfo:nil] raise ]; }
    [names removeObject: name];
}
@end

@interface CustomerBookTests : XCTestCase {
    CustomerBook *customerBook;
}

@end

@implementation CustomerBookTests

- (void)setUp {
    [super setUp];
    customerBook = [CustomerBook new];
}

- (void)testAddingCustomerShouldNotTakeMoreThan50Milliseconds {
    NSDate *startTime = [NSDate date];
    [customerBook addCustomerNamed:@"John Lennon"];
    NSTimeInterval elapsedTime = [[NSDate date] timeIntervalSinceDate: startTime ];
    XCTAssert(elapsedTime<50);
}

- (void)testRemovingCustomerShouldNotTakeMoreThan100Milliseconds {
    NSString *paulMcCartney = @"Paul McCartney";
    
    [ customerBook addCustomerNamed: paulMcCartney];
    
    NSDate *startTime = [NSDate date];
    [customerBook removeCustomerNamed: paulMcCartney];
    NSTimeInterval elapsedTime = [[NSDate date] timeIntervalSinceDate: startTime ];
    XCTAssert(elapsedTime<100);
}

- (void)testCanNotAddACustomerWithEmptyName {
    @try{
        [customerBook addCustomerNamed:@""];
        XCTFail();
    }
    @catch (NSException *e) {
        XCTAssertEqual([e name], @"Customer name can not be empty");
        XCTAssert([customerBook isEmpty]);
    }
}

- (void)testCanNotRemoveNotAddedCustomers {
    @try{
        [customerBook removeCustomerNamed:@"John Lennon"];
        XCTFail();
    }
    @catch (NSException *e) {
        XCTAssertEqual([e name], @"Invalid Customer name");
    }
}

@end
