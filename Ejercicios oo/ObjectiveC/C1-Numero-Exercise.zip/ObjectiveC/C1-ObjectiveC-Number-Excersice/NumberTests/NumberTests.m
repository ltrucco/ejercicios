//
//  NumberTests.m
//  NumberTests
//
//  Created by hernan on 13/12/15.
//  Copyright © 2015 10Pines. All rights reserved.
//

#import <XCTest/XCTest.h>

@class Entero;
@class Fraccion;

@interface Numero : NSObject

- (BOOL) esCero;
- (BOOL) esUno;
- (Numero*) mas:(Numero*) sumando;
- (Numero*) por:(Numero*) multiplicador;
- (Numero*) dividido:(Numero*) divisor;
@end

@implementation Numero
#define mustImplement @throw [NSException exceptionWithName:@"Must implemment method" reason:nil userInfo:nil];


- (BOOL) esCero {
    mustImplement
}

- (BOOL) esUno {
    mustImplement
}

- (Numero*) mas:(Numero*) sumando {
    mustImplement
}

- (Numero*) por:(Numero*) multiplicador {
    mustImplement
}

- (Numero*) dividido:(Numero*) divisor {
    mustImplement
}

@end

@interface Entero : Numero {
    int value;
}
@end

@interface Fraccion : Numero {
    Entero* numerador;
    Entero* denominador;
}
+(Numero*) dividir:(Entero*) dividendo con:(Entero*) divisor;
-(Entero*) numerador;
-(Entero*) denominador;
@end

@implementation Entero

+ (id) para: (int) aValue {
    return [[self new] init: aValue];
}

- (id) init: (int) aValue {
    value = aValue;
    return self;
}

- (int) value{
    return value;
}

- (BOOL) esCero {
    return value==0;
}

- (BOOL) esUno {
    return value==1;
}

- (Numero*) mas:(Numero*) sumando {
    return [Entero para: [((Entero*) sumando) value] + value];
}

- (Numero*) por:(Numero*) multiplicador {
    return [Entero para: [((Entero*) multiplicador) value] * value];
}

- (Numero*) dividido:(Numero*) divisor {
    return [Fraccion dividir: self con: divisor];
}

- (Entero*) maximoComunDivisorCon:(Entero*) otroEntero {
    if ([otroEntero esCero])
        return self;
    else
        return [otroEntero maximoComunDivisorCon: [self restoCon: otroEntero]];
}

- (Entero*) restoCon: (Entero*) divisor {
    return [Entero para: value%[divisor value]];
}

- (Entero*) divisionEntera: (Entero*) divisor {
    return [Entero para: value/[divisor value]];
}

- (BOOL) isEqual:(id)other {
    if (other == self)
        return YES;
    if (!other || ![other isKindOfClass:[self class]])
        return NO;
    return [self isEqualToEntero:other];
}

- (BOOL) isEqualToEntero:(Entero*) other {
    return value == [other value];
}

- (NSUInteger) hash {
    return value;
}

@end


@implementation Fraccion

+(Numero*) dividir:(Entero*) dividendo con:(Entero*) divisor {
    if([divisor esCero]) [[NSException exceptionWithName:@"No se puede dividir por 0" reason:nil userInfo:nil] raise ];
    if([dividendo esCero]) return dividendo;
    
    Entero* maximoComunDivisor = [dividendo maximoComunDivisorCon: divisor];
    Entero* numerador = [dividendo divisionEntera: maximoComunDivisor];
    Entero* denominador = [divisor divisionEntera: maximoComunDivisor];
    
    if ([denominador esUno]) return numerador;
    
    return [Fraccion numerador: numerador denominador: denominador];
}

+(Fraccion*) numerador:(Entero*) aNumerador denominador:(Entero*) aDenominador {
    return [[self new] init: aNumerador and: aDenominador];
}

-(id) init: (Entero*) aNumerador and:(Entero*) aDenominador {
    numerador = aNumerador;
    denominador = aDenominador;
    
    return self;
}

-(Entero*) numerador {
    return numerador;
}

-(Entero*) denominador {
    return denominador;
}

- (BOOL) esCero {
    return NO;
}

- (BOOL) esUno {
    return NO;
}

- (Numero*) mas:(Numero*) sumando {
    Fraccion* sumandoAsFraccion = (Fraccion*) sumando;
     
     Numero* numerador1 = [numerador por: [sumandoAsFraccion denominador]];
     Numero* numerador2 = [denominador por: [sumandoAsFraccion numerador]];
     Numero* denominadorComun = [denominador por: [sumandoAsFraccion denominador]];
     
     return [[numerador1 mas: numerador2] dividido: denominadorComun];
}

- (Numero*) por:(Numero*) multiplicador {
     Fraccion* multiplicadorAsFraccion = (Fraccion*) multiplicador;
     
     Numero* nuevoNumerador = [numerador por: [multiplicadorAsFraccion numerador]];
     Numero* denominadorComun = [denominador por: [multiplicadorAsFraccion denominador]];
     
     return [nuevoNumerador dividido: denominadorComun];
}

- (Numero*) dividido:(Numero*) divisor {
     Fraccion* divisorAsFraccion = (Fraccion*) divisor;
     
     Numero* nuevoNumerador = [numerador por: [divisorAsFraccion denominador]];
     Numero* denominadorComun = [denominador por: [divisorAsFraccion numerador]];
     
     return [nuevoNumerador dividido: denominadorComun];
}

- (BOOL) isEqual:(id)other {
    if (other == self)
        return YES;
    if (!other || ![other isKindOfClass:[self class]])
        return NO;
    return [self isEqualToFraccion:other];
}

- (BOOL) isEqualToFraccion:(Fraccion*) other {
    return [numerador isEqual: [other numerador]] && [denominador isEqual: [other denominador]];
}

- (NSUInteger) hash {
    return [numerador value];
}

@end

@interface NumberTests : XCTestCase {
    Numero* cero;
    Numero* uno;
    Numero* dos;
    Numero* tres;
    Numero* cuatro;
    Numero* cinco;
    
    Numero* unQuinto;
    Numero* dosQuintos;
    Numero* tresQuintos;
    Numero* dosVeinticincoavos;
    Numero* unMedio;
    Numero* cincoMedios;
    Numero* seisQuintos;
    Numero* cuatroMedios;
    Numero* dosCuartos;
}

@end

@implementation NumberTests

- (void)setUp {
    [super setUp];
    
    cero = [Entero para:0];
    uno = [Entero para:1];
    dos = [Entero para:2];
    tres = [Entero para:3];
    cuatro = [Entero para:4];
    cinco = [Entero para:5];
    
    unQuinto = [uno dividido: cinco];
    dosQuintos = [dos dividido: cinco];
    tresQuintos = [tres dividido: cinco];
    dosVeinticincoavos = [dos dividido: [Entero para:25]];
    unMedio = [uno dividido: dos];
    cincoMedios = [cinco dividido: dos];
    seisQuintos = [[Entero para:6] dividido: cinco];
    cuatroMedios = [cuatro dividido: dos];
    dosCuartos = [dos dividido: cuatro];
}


- (void)testEsCeroDevuelveTrueSoloParaElCero {
    XCTAssert([cero esCero]);
    XCTAssertFalse([uno esCero]);
}

- (void)testEsUnoDevuelveTrueSoloParaElUno {
    XCTAssert([uno esUno]);
    XCTAssertFalse([cero esUno]);
}

- (void) testSumaDeEnteros {
    XCTAssertEqualObjects(dos,[uno mas:uno]);
}

- (void) testMultiplicacionDeEnteros {
    XCTAssertEqualObjects(cuatro, [dos por: dos]);
}

- (void) testDivisionDeEnteros {
    XCTAssertEqualObjects(uno, [dos dividido: dos]);
}

- (void) testSumaDeFracciones {
    Numero* sieteDecimos = [[Entero para: 7] dividido: [Entero para: 10]];
    XCTAssertEqualObjects (sieteDecimos, [unQuinto mas: unMedio]);
    /*
     * La suma de fracciones es:
     *
     * a/b + c/d = (a.d + c.b) / (b.d)
     *
     * SI ESTAN PENSANDO EN LA REDUCCION DE FRACCIONES NO SE PREOCUPEN!
     * TODAVIA NO SE ESTA TESTEANDO ESE CASO
     */
}

- (void) testMultiplicacionDeFracciones {
    XCTAssertEqualObjects (dosVeinticincoavos,[unQuinto por: dosQuintos]);
    /*
     * La multiplicación de fracciones es:
     *
     * (a/b) * (c/d) = (a.c) / (b.d)
     *
     * SI ESTAN PENSANDO EN LA REDUCCION DE FRACCIONES NO SE PREOCUPEN!
     * TODAVIA NO SE ESTA TESTEANDO ESE CASO
     */
}

- (void) testDivisionDeFracciones {
    XCTAssertEqualObjects (cincoMedios,[unMedio dividido: unQuinto]);
    /*
     * La división de fracciones es:
     *
     * (a/b) / (c/d) = (a.d) / (b.c)
     *
     * SI ESTAN PENSANDO EN LA REDUCCION DE FRACCIONES NO SE PREOCUPEN!
     * TODAVIA NO SE ESTA TESTEANDO ESE CASO
     */
}

/*
 * Ahora empieza lo lindo! - Primero hacemos que se puedan sumar enteros con fracciones
 * y fracciones con enteros
 */
- (void) testSumaDeEnteroYFraccion {
    XCTAssertEqualObjects (seisQuintos,[uno mas: unQuinto]);
}

- (void) testSumaDeFraccionYEntero {
    XCTAssertEqualObjects (seisQuintos,[unQuinto mas: uno]);
}

/*
 * Hacemos lo mismo para la multipliación
 */
- (void) testMultiplicacionDeEnteroPorFraccion {
    XCTAssertEqualObjects (dosQuintos,[dos por: unQuinto]);
}

- (void) testMultiplicacionDeFraccionPorEntero {
    XCTAssertEqualObjects (dosQuintos,[unQuinto por: dos]);
}

/*
 * Hacemos lo mismo para la division
 */
- (void) testDivisionDeEnteroPorFraccion {
    XCTAssertEqualObjects(cincoMedios,[uno dividido: dosQuintos]);
}

- (void) testDivisionDeFraccionPorEntero {
    XCTAssertEqualObjects(dosVeinticincoavos,[dosQuintos dividido: cinco]);
}

/*
 * Ahora si empezamos con problemas de reducción de fracciones
 */
- (void) testUnaFraccionPuedeSerIgualAUnEntero {
    XCTAssertEqualObjects(dos,cuatroMedios);
}

- (void) testLasFraccionesAparentesSonIguales {
    XCTAssertEqualObjects(unMedio,dosCuartos);
    /*
     * Las fracciones se reducen utilizando el maximo comun divisor (mcd)
     * Por lo tanto, para a/b, sea c = mcd (a,b) => a/b reducida es:
     * (a/c) / (b/c).
     *
     * Por ejemplo: a/b = 2/4 entonces c = 2. Por lo tanto 2/4 reducida es:
     * (2/2) / (4/2) = 1/2
     *
     * Para obtener el mcd pueden usar el algoritmo de Euclides que es:
     *
     * mcd (a,b) =
     * 		si b = 0 --> a
     * 		si b != 0 -->mcd(b, restoDeDividir(a,b))
     *
     * Ejemplo:
     * mcd(2,4) ->
     * mcd(4,restoDeDividir(2,4)) ->
     * mcd(4,2) ->
     * mcd(2,restoDeDividir(4,2)) ->
     * mcd(2,0) ->
     * 2
     */
}

- (void) testLaSumaDeFraccionesPuedeDarEntero {
    XCTAssertEqualObjects (uno,[unMedio mas: unMedio]);
}

- (void) testLaMultiplicacionDeFraccionesPuedeDarEntero {
    XCTAssertEqualObjects(dos, [cuatro por: unMedio]);
}

- (void) testLaDivisionDeEnterosPuedeDarFraccion {
    XCTAssertEqualObjects(unMedio, [dos dividido: cuatro]);
}

- (void) testLaDivisionDeFraccionesPuedeDarEntero {
    XCTAssertEqualObjects(uno, [unMedio dividido: unMedio]);
}

- (void) testNoSePuedeDividirEnteroPorCero {
    [self debeFallarConDivisionPorCero: ^{[uno dividido: cero];}];
}

- (void) testNoSePuedeDividirFraccionPorCero {
    [self debeFallarConDivisionPorCero: ^{[unQuinto dividido: cero];}];
}

- (void) debeFallarConDivisionPorCero: (void (^)(void)) closure {
    @try {
        closure();
        XCTFail();
    }
    @catch (NSException* e) {
        XCTAssertEqual([e name], @"No se puede dividir por 0");
    }
}

@end
