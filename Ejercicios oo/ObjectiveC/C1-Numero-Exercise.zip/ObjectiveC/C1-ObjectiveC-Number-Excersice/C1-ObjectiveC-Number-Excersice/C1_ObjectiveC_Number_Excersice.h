//
//  C1_ObjectiveC_Number_Excersice.h
//  C1-ObjectiveC-Number-Excersice
//
//  Created by hernan on 13/12/15.
//  Copyright © 2015 10Pines. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface C1_ObjectiveC_Number_Excersice : NSObject

@end
