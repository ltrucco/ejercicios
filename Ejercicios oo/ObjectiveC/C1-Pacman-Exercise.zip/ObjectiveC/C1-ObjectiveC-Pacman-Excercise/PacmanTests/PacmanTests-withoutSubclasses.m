//
//  PacmanTests.m
//  PacmanTests
//
//  Created by Hernan Wilkinson on 12/15/15.
//  Copyright © 2015 Hernan Wilkinson. All rights reserved.
//

#import <XCTest/XCTest.h>

#define mustImplement @throw [NSException exceptionWithName:@"Must implemment method" reason:nil userInfo:nil];

@interface PacmanPoint : NSObject {
    NSInteger x;
    NSInteger y;
}
@end

@implementation PacmanPoint

+(id)x:(NSInteger) aX y:(NSInteger) aY {
    return [[self new] initX: aX y: aY];
}

-(id)initX:(NSInteger) aX y:(NSInteger) aY {
    x = aX;
    y = aY;
    return self;
}

- (BOOL) isEqual:(id) other {
    if (other == self)
        return YES;
    if (!other || ![other isKindOfClass:[self class]])
        return NO;
    return [self isEqualToPacmanPoint: other];
}

- (BOOL) isEqualToPacmanPoint:(PacmanPoint*) other {
    return (x == [other x]) && (y==[other y]);
}

- (NSUInteger) hash {
    return x;
}

- (NSInteger) x {
    return x;
}

- (NSInteger) y {
    return y;
}

- (PacmanPoint*) plus:(PacmanPoint*) aPoint {
    return [PacmanPoint x: (x+[aPoint x]) y: (y+[aPoint y])];
}
@end

@interface Actor : NSObject
@end

@class ConstructionBlockType;

@implementation Actor

- (PacmanPoint*) position { mustImplement }

@end

@interface ConstructionBlockType: NSObject
@end

@implementation ConstructionBlockType

- (PacmanPoint*) nextPositionFor:(Actor*) anActor going:(PacmanPoint*) aMovement {
    mustImplement
}

@end


@interface PacmanTests : XCTestCase {
    //NO SE PUEDE CAMBIAR EL TIPO DE LAS VARIABLES
    //SI SE PUEDEN CREAR CLASES ESPECIALES PARA CADA
    //ACTOR O CONSTRUCTIONBLOCKTYPE
    Actor* pacman;
    Actor* blueGhost;
    ConstructionBlockType* wallType;
    ConstructionBlockType* spaceType;
    ConstructionBlockType* leftTransporterType;
    ConstructionBlockType* ghostHouseDoorType;
    
    PacmanPoint* left;
    PacmanPoint* right;
    PacmanPoint* up;
    PacmanPoint* down;
}
@end

@implementation PacmanTests

- (void)setUp {
    [super setUp];
    pacman = [Actor new];
    blueGhost = [Actor new];
    
    wallType = [ConstructionBlockType new];
    spaceType = [ConstructionBlockType new];
    ghostHouseDoorType = [ConstructionBlockType new];
    leftTransporterType = [ConstructionBlockType new];
    
    left = [PacmanPoint x:-1 y:0];
    right = [PacmanPoint x:1 y:0];
    up = [PacmanPoint x:0 y:1];
    down = [PacmanPoint x:0 y:-1];
}


-(void) testGhostCanNotGoIntoAWall {
    XCTAssertEqualObjects(
                          [blueGhost position],
                          [wallType nextPositionFor: blueGhost going:left]);
    
    XCTAssertEqualObjects(
                          [blueGhost position],
                          [wallType nextPositionFor: blueGhost going:right]);
    
    XCTAssertEqualObjects(
                          [blueGhost position],
                          [wallType nextPositionFor: blueGhost going:up]);
    
    XCTAssertEqualObjects(
                          [blueGhost position],
                          [wallType nextPositionFor: blueGhost going:down]);
}

-(void) testPacmanCanNotGoIntoAWall {
    XCTAssertEqualObjects(
                          [pacman position],
                          [wallType nextPositionFor: pacman going: left]);
    
    XCTAssertEqualObjects(
                          [pacman position],
                          [wallType nextPositionFor: pacman going: right]);
    
    XCTAssertEqualObjects(
                          [pacman position],
                          [wallType nextPositionFor: pacman going: up]);
    
    XCTAssertEqualObjects(
                          [pacman position],
                          [wallType nextPositionFor: pacman going: down]);
}

-(void) testPacmanMovesIntoSpacesVeryFast {
    XCTAssertEqualObjects(
                          [[pacman position] plus:[PacmanPoint x:-2 y:0]],
                          [spaceType nextPositionFor: pacman going: left]);
    
    XCTAssertEqualObjects(
                          [[pacman position] plus:[PacmanPoint x:2 y:0]],
                          [spaceType nextPositionFor: pacman going: right]);
    
    XCTAssertEqualObjects(
                          [[pacman position] plus:[PacmanPoint x:0 y:2]],
                          [spaceType nextPositionFor: pacman going: up]);
    
    XCTAssertEqualObjects(
                          [[pacman position] plus:[PacmanPoint x:0 y:-2]],
                          [spaceType nextPositionFor: pacman going: down]);
    
}

-(void) testGhostMovesIntoSpacesSlowly {
    XCTAssertEqualObjects(
                          [[blueGhost position] plus: [PacmanPoint x:-1 y:0]],
                          [spaceType nextPositionFor: blueGhost going: left]);
    
    XCTAssertEqualObjects(
                          [[blueGhost position] plus: [PacmanPoint x:1 y:0]],
                          [spaceType nextPositionFor: blueGhost going: right]);
    
    XCTAssertEqualObjects(
                          [[blueGhost position] plus: [PacmanPoint x:0 y:1]],
                          [spaceType nextPositionFor: blueGhost going: up]);
    
    XCTAssertEqualObjects(
                          [[blueGhost position] plus: [PacmanPoint x:0 y:-1]],
                          [spaceType nextPositionFor: blueGhost going: down]);
}

-(void) testGhostCanEnterHisHouse {
    XCTAssertEqualObjects(
                          [[blueGhost position] plus: [PacmanPoint x:-1 y:0]],
                          [ghostHouseDoorType nextPositionFor: blueGhost going: left]);
    
    XCTAssertEqualObjects(
                          [[blueGhost position] plus: [PacmanPoint x:1 y:0]],
                          [ghostHouseDoorType nextPositionFor: blueGhost going: right]);
    
    XCTAssertEqualObjects(
                          [[blueGhost position] plus: [PacmanPoint x:0 y:1]],
                          [ghostHouseDoorType nextPositionFor: blueGhost going: up]);
    
    XCTAssertEqualObjects(
                          [[blueGhost position] plus: [PacmanPoint x:0 y:-1]],
                          [ghostHouseDoorType nextPositionFor: blueGhost going: down]);
}

-(void) testPacmanCanNotEnterGhostHouse {
    XCTAssertEqualObjects(
                          [pacman position],
                          [ghostHouseDoorType nextPositionFor: pacman going: left]);
    
    XCTAssertEqualObjects(
                          [pacman position],
                          [ghostHouseDoorType nextPositionFor: pacman going: right]);
    
    XCTAssertEqualObjects(
                          [pacman position],
                          [ghostHouseDoorType nextPositionFor: pacman going: up]);
    
    XCTAssertEqualObjects(
                          [pacman position],
                          [ghostHouseDoorType nextPositionFor: pacman going: down]);
}

-(void) testTransporterMovesPacmanToNewPosition {
    XCTAssertEqualObjects(
                          [PacmanPoint x:10 y:4],
                          [leftTransporterType nextPositionFor: pacman going: left]);
    
    XCTAssertEqualObjects(
                          [PacmanPoint x:10 y:4],
                          [leftTransporterType nextPositionFor: pacman going: right]);
}

-(void) testGhostCanNotGoIntoTransporter {
    XCTAssertEqualObjects(
                          [blueGhost position],
                          [leftTransporterType nextPositionFor: blueGhost going: left]);
    
    XCTAssertEqualObjects(
                          [blueGhost position],
                          [leftTransporterType nextPositionFor: blueGhost going: right]);
}
@end
