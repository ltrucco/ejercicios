//
//  StackTests.m
//  StackTests
//
//  Created by Hernan Wilkinson on 12/18/15.
//  Copyright © 2015 Hernan Wilkinson. All rights reserved.
//

#import <XCTest/XCTest.h>

#define mustImplement @throw [NSException exceptionWithName:@"Must implemment method" reason:nil userInfo:nil];

@interface Stack : NSObject
@end

@implementation Stack

-(void) push: (NSObject*) anObject { mustImplement }
-(NSObject*) pop { mustImplement }
-(NSObject*) top { mustImplement }
-(NSUInteger) size { mustImplement }
-(BOOL) isEmpty { mustImplement }

@end

@interface StackTests : XCTestCase

@end

@implementation StackTests

-(void) testStackShouldBeEmptyWhenCreated{
    Stack* stack = [Stack new];
    
    XCTAssert([stack isEmpty]);
}

-(void) testPushAddElementsToTheStack {
    Stack* stack = [Stack new];
    [stack push: @"Something"];
    
    XCTAssertFalse([stack isEmpty]);
}

-(void) testPopRemovesElementsFromTheStack {
    Stack* stack = [Stack new];
    [stack push: @"Something"];
    [stack pop];
    
    XCTAssert([stack isEmpty]);
}

-(void) testPopReturnsLastPushedObject {
    Stack* stack = [Stack new];
    NSString* pushedObject = @"Something";
    [stack push:pushedObject];
    XCTAssertEqualObjects(pushedObject, [stack pop]);
}

-(void) testStackBehavesLIFO  {
    NSString* firstPushed = @"First";
    NSString* secondPushed = @"Second";
    Stack* stack = [Stack new];
    [stack push: firstPushed];
    [stack push: secondPushed];
    
    XCTAssertEqualObjects(secondPushed,[stack pop]);
    XCTAssertEqualObjects(firstPushed,[stack pop]);
    XCTAssert([stack isEmpty]);
}

-(void) testTopReturnsLastPushedObject {
    Stack* stack = [Stack new];
    NSString* pushedObject = @"Something";
    
    [stack push: pushedObject];
    
    XCTAssertEqualObjects(pushedObject, [stack top]);
}

-(void) testTopDoesNotRemoveObjectFromStack {
    Stack* stack = [Stack new];
    NSString* pushedObject = @"Something";
    
    [stack push: pushedObject];
    
    XCTAssertEqual(1,[stack size]);
    [stack top];
    XCTAssertEqual(1,[stack size]);
}

-(void) testCanNotPopWhenThereAreNoObjectsInTheStack {
    Stack* stack = [Stack new];
    
    @try {
        [stack pop];
        XCTFail();
    }
    @catch (NSException* stackIsEmpty){
        XCTAssertEqualObjects(@"Stack is empty",[stackIsEmpty name]);
    }
}

-(void) testCanNotTopWhenThereAreNoObjectsInTheStack {
    Stack* stack = [Stack new];
    
    @try {
        [stack top];
        XCTFail();
    }
    @catch (NSException* stackIsEmpty){
        XCTAssertEqualObjects(@"Stack is empty",[stackIsEmpty name]);
    }
}

@end
