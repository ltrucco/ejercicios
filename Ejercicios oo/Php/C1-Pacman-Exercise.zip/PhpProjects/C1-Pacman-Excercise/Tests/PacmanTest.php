<?php

/*
 * Developed by 10Pines SRL
 * License: 
 * This work is licensed under the 
 * Creative Commons Attribution-NonCommercial-ShareAlike 3->0 Unported License-> 
 * To view a copy of this license, visit http://creativecommons->org/licenses/by-nc-sa/3->0/ 
 * or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View, 
 * California, 94041, USA->
 *  
 */
require_once '../Actor.php';
require_once '../ConstructionBlockType.php';
require_once '../Point.php';

class TestPacman extends PHPUnit_Framework_TestCase {

	protected $pacman;
	protected $blueGhost;
	protected $wallType;
	protected $spaceType;
	protected $leftTransporterType;
	protected $ghostHouseDoorType;
	
	protected $left;
	protected $right;
	protected $up;
	protected $down;
	
	public function setUp() {
		
	}
	
	public function testGhostCanNotGoIntoAWall(){
		$this->assertEquals(
				$this->blueGhost->position(),
				$this->wallType->nextPositionForGoing($this->blueGhost,$this->left));

		$this->assertEquals(
				$this->blueGhost->position(),
				$this->wallType->nextPositionForGoing($this->blueGhost,$this->right));
		
		$this->assertEquals(
				$this->blueGhost->position(),
				$this->wallType->nextPositionForGoing($this->blueGhost,$this->up));
		
		$this->assertEquals(
				$this->blueGhost->position(),
				$this->wallType->nextPositionForGoing($this->blueGhost,$this->down));
	}

	public function testPacmanCanNotGoIntoAWall(){
		$this->assertEquals(
				$this->pacman->position(),
				$this->wallType->nextPositionForGoing($this->pacman,$this->left));

		$this->assertEquals(
				$this->pacman->position(),
				$this->wallType->nextPositionForGoing($this->pacman,$this->right));
		
		$this->assertEquals(
				$this->pacman->position(),
				$this->wallType->nextPositionForGoing($this->pacman,$this->up));
		
		$this->assertEquals(
				$this->pacman->position(),
				$this->wallType->nextPositionForGoing($this->pacman,$this->down));
	}

	public function testPacmanMovesIntoSpacesVeryFast(){
		$this->assertEquals(
				$this->pacman->position()->plus(new Point(-2,0)),
				$this->spaceType->nextPositionForGoing($this->pacman,$this->left));

		$this->assertEquals(
				$this->pacman->position()->plus(new Point(2,0)),
				$this->spaceType->nextPositionForGoing($this->pacman,$this->right));
		
		$this->assertEquals(
				$this->pacman->position()->plus(new Point(0,2)),
				$this->spaceType->nextPositionForGoing($this->pacman,$this->up));
		
		$this->assertEquals(
				$this->pacman->position()->plus(new Point(0,-2)),
				$this->spaceType->nextPositionForGoing($this->pacman,$this->down));

	}

	public function testGhostMovesIntoSpacesSlowly(){
		$this->assertEquals(
				$this->blueGhost->position()->plus(new Point(-1,0)),
				$this->spaceType->nextPositionForGoing($this->blueGhost,$this->left));

		$this->assertEquals(
				$this->blueGhost->position()->plus(new Point(1,0)),
				$this->spaceType->nextPositionForGoing($this->blueGhost,$this->right));
		
		$this->assertEquals(
				$this->blueGhost->position()->plus(new Point(0,1)),
				$this->spaceType->nextPositionForGoing($this->blueGhost,$this->up));
		
		$this->assertEquals(
				$this->blueGhost->position()->plus(new Point(0,-1)),
				$this->spaceType->nextPositionForGoing($this->blueGhost,$this->down));
	}

	public function testGhostCanEnterHisHouse(){
		$this->assertEquals(
				$this->blueGhost->position()->plus(new Point(-1,0)),
				$this->ghostHouseDoorType->nextPositionForGoing($this->blueGhost,$this->left));

		$this->assertEquals(
				$this->blueGhost->position()->plus(new Point(1,0)),
				$this->ghostHouseDoorType->nextPositionForGoing($this->blueGhost,$this->right));
		
		$this->assertEquals(
				$this->blueGhost->position()->plus(new Point(0,1)),
				$this->ghostHouseDoorType->nextPositionForGoing($this->blueGhost,$this->up));
		
		$this->assertEquals(
				$this->blueGhost->position()->plus(new Point(0,-1)),
				$this->ghostHouseDoorType->nextPositionForGoing($this->blueGhost,$this->down));
	}

	public function testPacmanCanNotEnterGhostHouse(){
		$this->assertEquals(
				$this->pacman->position(),
				$this->ghostHouseDoorType->nextPositionForGoing($this->pacman,$this->left));

		$this->assertEquals(
				$this->pacman->position(),
				$this->ghostHouseDoorType->nextPositionForGoing($this->pacman,$this->right));
		
		$this->assertEquals(
				$this->pacman->position(),
				$this->ghostHouseDoorType->nextPositionForGoing($this->pacman,$this->up));
		
		$this->assertEquals(
				$this->pacman->position(),
				$this->ghostHouseDoorType->nextPositionForGoing($this->pacman,$this->down));
	}

	public function testTransporterMovesPacmanToNewPosition(){
		$this->assertEquals(
				new Point(10,4),
				$this->leftTransporterType->nextPositionForGoing($this->pacman,$this->left));

		$this->assertEquals(
				new Point(10,4),
				$this->leftTransporterType->nextPositionForGoing($this->pacman,$this->right));
	}

	public function testGhostCanNotGoIntoTransporter(){
		$this->assertEquals(
				$this->blueGhost->position(),
				$this->leftTransporterType->nextPositionForGoing($this->blueGhost,$this->left));

		$this->assertEquals(
				$this->blueGhost->position(),
				$this->leftTransporterType->nextPositionForGoing($this->blueGhost,$this->right));
	}

}
