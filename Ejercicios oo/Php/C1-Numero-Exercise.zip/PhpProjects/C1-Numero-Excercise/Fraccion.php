<?php

/*
 * Developed by 10Pines SRL
 * License: 
 * This work is licensed under the 
 * Creative Commons Attribution-NonCommercial-ShareAlike 3->0 Unported License-> 
 * To view a copy of this license, visit http://creativecommons->org/licenses/by-nc-sa/3->0/ 
 * or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View, 
 * California, 94041, USA->
 *  
 */

class Fraccion extends Numero {

	protected $numerador;
	protected $denominador;
	
	public static function dividir($dividendo, $divisor ) {
		
		if($divisor->esCero()) throw new RuntimeException (Numero::DESCRIPCION_DE_ERROR_NO_SE_PUEDE_DIVIDIR_POR_CERO);
		if($dividendo->esCero()) return $dividendo;
		
		$maximoComunDivisor = $dividendo->maximoComunDivisorCon($divisor);
		$numerador = $dividendo->divisionEntera($maximoComunDivisor);
		$denominador = $divisor->divisionEntera($maximoComunDivisor);
		
		if ($denominador->esUno()) return $numerador;
		
		return new Fraccion($numerador,$denominador);
	}
	
	private function __construct($numerador, $denominador){
		$this->numerador = $numerador;
		$this->denominador = $denominador;
	}
	
	public function numerador (){
		return $this->numerador;
	}
	
	public function denominador(){
		return $this->denominador;
	}

	public function esCero() {
		return false;
	}

	public function esUno() {
		return false;
	}
	
	public function mas($sumando) {
		return $this->numerador->por($sumando->denominador())
                        ->mas($this->denominador->por($sumando->numerador()))
                        ->dividido($this->denominador->por($sumando->denominador()));
	}

	public function por($multiplicador) {
		return $this->numerador->por($multiplicador->numerador())
                        ->dividido($this->denominador->por($multiplicador->denominador()));
	}
	
	public function dividido($divisor) {
		return $this->numerador->por($divisor->denominador())
                        ->dividido($this->denominador->por($divisor->numerador()));
	}
        
        public function value(){
            throw new RuntimeException("Este metodo no deberia ser ejecutado");
        }
        
      	public function maximoComunDivisorCon($otroEntero) {
            throw new RuntimeException("Este metodo no deberia ser ejecutado");
        }

}