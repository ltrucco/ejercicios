<?php

/*
 * Developed by 10Pines SRL
 * License: 
 * This work is licensed under the 
 * Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. 
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/ 
 * or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View, 
 * California, 94041, USA.
 *  
 */

class Entero extends Numero {

	protected $value;
	
	function __construct($value){
		$this->value = $value;
	}
	
	public function value(){
		return $this->value;
	}
	
	public function mas($sumando) {
		return new Entero ($this->value+$sumando->value());
	}

	public function por($multiplicador) {
		return new Entero ($this->value*$multiplicador->value());
	}

	public function dividido($divisor) {
		return Fraccion::dividir($this,$divisor);
	}

	public function esCero () {
		return $this->value == 0;
	}

	public function esUno() {
		return $this->value == 1;
	}


	public function maximoComunDivisorCon($otroEntero) {
		if ($otroEntero->esCero()) 
			return $this;
		else
			return $otroEntero->maximoComunDivisorCon($this->restoCon($otroEntero));
	}
	
	public function restoCon($divisor) {
		return new Entero ($this->value % $divisor->value());
	}
	
	public function divisionEntera($divisor){
		return new Entero ($this->value/$divisor->value());
	}
        
        public function denominador(){
            throw new RuntimeException("Este metodo no deberia ser ejecutado");
        }

        public function numerador(){
            throw new RuntimeException("Este metodo no deberia ser ejecutado");
        }


}
